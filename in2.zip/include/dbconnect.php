<?php
$servername = "localhost";
$username = "root";
$password = "";
$db="in2goods";
// Create connection
$connect= mysqli_connect($servername,$username,$password,$db);

?>